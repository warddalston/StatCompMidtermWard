#' BMAPack
#'
#' @name BMAPack
#' @docType package
NULL
